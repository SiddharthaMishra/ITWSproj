<?php 
  ini_set('display_errors',1);  error_reporting(E_ALL);
  include("config.php");
  session_start();
?> 

<!DOCTYPE html>
<html>

<head>
  <title>Flappy Bird</title>
  <link rel="stylesheet" type="text/css" href="gradient.css" />
  <link rel="stylesheet" type="text/css" href="homepage2.css" />
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
</head>

<body>
<br><br><br><br><br>  
  <div style="text-align:center">
    <canvas style="border:1px solid black;"id="canvas" width="800" height="480"></canvas>
  </div>
  <script src="app.js"></script>
  <script>
    document.getElementById('canvas').focus();
    playFB(<?php if(isset ($_SESSION['login_user'])) echo "\"".$_SESSION['login_user']."\""; ?>);
  </script>
  <img src="logo.gif">
  </div>
  <div id="homemenu">
    <a href="">HOME</a>
    <a href="">GAMES</a>
    <a href="">LEADERBOARD</a>
    <a href="">ABOUT US</a>
    <a href="">FEEDBACK</a>
  <img src="logo.gif">     
  </div> 
  <div id="homemenu2">
    <?php if(!isset($_SESSION["login_user"])) : ?>
    <a href="login.php">Log In</a>
    <a href="register.php">Register</a>
    <?php else : ?>
    <a href="logout.php">Logout</a>
    <span style="color:white">
      <?php echo "<a href=''> Welcome ".$_SESSION['login_user']."</a>" ?>
    </span>
    <?php endif ?>
  </div>
</body>

</html>