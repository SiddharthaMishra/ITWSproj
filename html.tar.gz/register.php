<!DOCTYPE html>
<?php
//  ini_set('display_errors',1);  error_reporting(E_ALL);
  include("config.php");
  session_start();
  if(isset($_POST['submit'])){
    $fname=pg_escape_string($db, $_POST['fname']);
    $uname=pg_escape_string($db, $_POST['username']);
    $lname=pg_escape_string($db, $_POST['fname']);
    $email=$_POST['email'];
    $password=$_POST['password'];
    $date=$_POST['date'];
    $exists=pg_query("SELECT * from users where username='$uname'");    
    if(pg_num_rows($exists)!=0){
      echo "<script type='text/javascript'>alert('Username already exists.');</script>";
    }    
    else{
      if($_POST['password']==$_POST['new_password']){
        $query="INSERT INTO users VALUES ('$uname','$fname','$lname','$email','$password','$date','$now');";
        $result=pg_query($query);
        if($result){
          $now= date("Y-m-d");
          echo "<script type='text/javascript'>alert('You have registered successfully.');
          window.location.replace(\"login.php\");
          </script>";       
        }
        else{
          echo "<script type='text/javascript'>alert('Please enter correct information.');</script>";
        }
      }
      else{

        echo "<script type='text/javascript'>alert('Passwords don't match.');</script>";
      }
    }
  }
?>
<html>
<head>
  <title>Sign Up</title>
  <link rel="stylesheet" type="text/css" href="HOMEPAGE.css" />
</head>
<body>
  <form id="form2" action="" method="POST">
  <?php if (!isset($_SESSION['login_user'])) : ?> 
    <h1>Create An Account</h1>
    <input type="text" pattern=".{3,}" name="username" value="<?php if(isset($uname)) echo $uname; else echo ''; ?>" placeholder="User Name" required><br>
    <input type="text" pattern=".{3,}" name="fname" value="<?php if(isset($fname)) echo $fname; else echo ''; ?>" placeholder="First Name" required><br>
    <input type="text" pattern=".{3,}" name="lname" value="<?php if(isset($lname)) echo $lname; else echo ''; ?>" placeholder="Last Name" required><br>
    <input type="Date" name="date" value="<?php if(isset($date)) echo $date; else echo ''; ?>" placeholder="DOB" required><br>
    <input type="email" name="email" value="<?php if(isset($email)) echo $email; else echo ''; ?>" placeholder="Email" required><br>
    <input type="password" pattern=".{5,}" name="password" placeholder="password" required><br>
    <input type="password" pattern=".{5,}" name="new_password" placeholder="confirm password" required><br>      
    <input type="submit" name="submit" value="Sign Up" >
    <p>Already have an account? <a href="login.php">Login Here</a></p>
  <?php else : ?>  
    You are already registered, click <a href="HOMEPAGE.php"> here</a> to go back.
  <?php endif ?>
  </form>

  <div id="mainmenu">
  <a href="">GAMES</a>
  <a href="">LEADERBOARD</a>
  <a href="">ABOUT US</a>
  </div>
   
  <div class="hl"></div>

  <div id="homemenu">
    <h1>WEBPAGE NAME</h1>
    <a href="HOMEPAGE.php"><img src="3.jpg"></a> 
    <div id="homemenu2">
      <?php if(!isset($_SESSION["login_user"])) : ?>
        <a href="login.php">Log In</a>    
        <a href="register.php">Register</a>
      <?php else : ?>
        <a href="logout.php">Logout</a>
        <span style="color:white"><?php echo "Welcome ".$_SESSION['login_user'] ?></span>
      <?php endif ?> 
    </div>   
  </div>

  <div class="vl"></div>     
</body>
</html>