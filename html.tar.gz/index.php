<?php 
  header("location: HOMEPAGE.php");
?>