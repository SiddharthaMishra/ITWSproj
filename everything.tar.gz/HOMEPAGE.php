<?php
  session_start();    
  ini_set('display_errors',1);  error_reporting(E_ALL);
  include("config.php");
  include('rememberme.php');
  if(!isset($_SESSION['login_user']))
    rememberMe();
?>  
<!DOCTYPE html>
<html>
<head>
  <link rel="icon" href="logotop">	
  <link href="https://fonts.googleapis.com/css?family=Roboto+Slab" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Indie+Flower|Mr+De+Haviland" rel="stylesheet"> 
	<title></title>
    <link rel="stylesheet" type="text/css" href="menu.css">
		<script type="text/javascript" src="menu.js"></script>
</head>
<body onload="sliderA()">
	<div id="menu">
		<div class="icon" onclick="togglesidebar()">
			<span></span>
			<span></span>
			<span></span>
		</div>
		<div class="dropdown">
			<a href="">GAMES</a>
			<div class="dropdown-cont">
				<a href="">GAME1</a>
				<a href="">GAME2</a>
				<a href="">GAME3</a>
				<a href="">GAME4</a>
				<a href="">GAME5</a>
				<a href="">GAME6</a>
			</div>
		</div>
		<a href="">LEADERBOARD</a>
		<a href="">ABOUT</a>
    <?php if(!isset($_SESSION["login_user"])) : ?>
    <a href="">SIGN UP</a>
    <a href="">LOGIN</a>
  <?php else :?>
    <a href="">LOGOUT</a>
  <?php endif ?>
</div>
		</div>

 <div id="firstdiv" >
 	<img src="logo.gif">
 	<p><h1>WANT TO HAVE SOME FUN.</h1></p>
 </div>

 <div id="seconddiv">
    <img id="image" src="1.jpg">
    <div id="left_button"><img src="left.png" onclick="slide(-1)"></div>
    <div id="right_button"><img src="right.png" onclick="slide(1)"></div>
 </div>

<div id="thirddiv">
	<div id="arrow">
	<a href=""><img src="arrow1.png"></a>
	</div>
	<div id="lastdiv">
		<img src="logo.gif"><br>
		<p>CATEGORIES</p>
		<a href="">Games</a>
		<a href="">Leaderboard</a>
		<a href="">Contact Us</a>
		<a href="">Terms Of Use</a>

		<p id="para">
			KEEP IN TOUCH<br><br>			
            <a href="">something@iiits.in</a>
            <a href="">something@iiits.in</a>
            <a href="">something@iiits.in</a>
            <a href="">something@iiits.in</a>
            <a href="">something@iiits.in</a>
		</p>
	</div>
 </div> 
</body>
</html>
