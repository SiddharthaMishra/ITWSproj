<?php 
  ini_set('display_errors',1);  error_reporting(E_ALL);
  include("config.php");
  session_start();
  include('rememberme.php');
  if(!isset($_SESSION['login_user']))
    rememberMe();
    
  function createTable($i){
    $query="SELECT * FROM allScores where gameid='$i' order by score desc";
    $result=pg_query($query);
    $rank=1;
    while($row= pg_fetch_assoc($result)){
      echo "<tr><td> $rank </td><td>".$row["username"]."</td><td>".$row["score"]."</td></tr>;";
      $rank++;
    }
  }
?> 

<!DOCTYPE html>
<html>
<head>
  <title>About</title>
  <link rel="stylesheet" type="text/css" href="signup.css" />
  <link rel="stylesheet" type="text/css" href="gradient.css">
  <link rel="stylesheet" type="text/css" href="homepage2.css" />
  <link rel="stylesheet" type="text/css" href="leaderboard.css">
</head>
<body>
  <div id="homemenu">
    <a href="">HOME</a>
    <a href="">GAMES</a>
    <a href="">LEADERBOARD</a>
    <a href="">ABOUT US</a>
    <a href="">FEEDBACK</a>
    <img src="logo.gif">     
  </div> 

  <div id="homemenu2">
    <?php if(!isset($_SESSION["login_user"])) : ?>
      <a href="login.php">Log In</a>
      <a href="register.php">Register</a>
    <?php else : ?>
      <a href="logout.php">Logout</a>
    <span style="color:white">
      <?php echo "<a href=''> Welcome ".$_SESSION['login_user']."</a>" ?>
    </span>
      <?php endif ?>
  </div>
    
  <div id="select">
    <a href="">GAME 1</a>
    <a href="">GAME 2</a>
    <a href="">GAME 3</a>
    <a href="">GAME 4</a>
    <a href="">GAME 5</a>   	
  </div> 

 
  <table>
    <tr>
      <th>Rank</th>
      <th>Username</th>
      <th>Score</th>
    </tr>
    <?php 
      createTable(1);
    ?>
  </table>

</body>
</html>     